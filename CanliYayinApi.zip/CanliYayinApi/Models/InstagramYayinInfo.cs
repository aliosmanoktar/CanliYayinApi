﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CanliYayinApi.Models
{
    public class InstagramYayinInfo
    {
        public string url { get; set; }
        public string YayinUid { get; set; }
        public string BroadCastid { get; set; }
    }
}