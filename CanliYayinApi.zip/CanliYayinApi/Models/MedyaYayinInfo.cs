﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CanliYayinApi.Models
{
    public class MedyaYayinInfo
    {
        public string YayinName;
        public string Link;
    }
}