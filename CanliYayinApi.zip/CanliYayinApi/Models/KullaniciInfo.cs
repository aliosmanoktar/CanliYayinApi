﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CanliYayinApi.Models
{
    public class KullaniciInfo
    {
        public int Id;
        public string Name;
        public string Sifre;
        public bool YayinDurum;
    }
}